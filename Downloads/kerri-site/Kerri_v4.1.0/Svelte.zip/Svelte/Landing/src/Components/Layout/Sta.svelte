<section class="section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="text-center">
                    <h2 class="fw-bold">I Am Available For Freelancer.</h2>
                </div>
                <div class="text-center mt-4">
                    <a href="#!" class="btn btn-primary">Hire Me!</a>
                </div>
            </div>
        </div>
    </div>
</section>