<script>
    import Typewriter from 'svelte-typewriter'
</script>

<Typewriter mode="loop" cursor=true --cursor-color="white" --cursor-width="6px" interval="50" >
    <span class="element fw-bold">Kerri Deo.</span> 
    <span class="element fw-bold">A Graphic Designer.</span>
    <span class="element fw-bold">A Photographer.</span>
</Typewriter>