<script>
    import ColorManager from "../ColorManager.svelte";
	import BackToTop from '../BackToTop.svelte';
    import ThemeManager from '../ThemeManager.svelte';
</script>

<BackToTop />
<ColorManager />
<ThemeManager />

