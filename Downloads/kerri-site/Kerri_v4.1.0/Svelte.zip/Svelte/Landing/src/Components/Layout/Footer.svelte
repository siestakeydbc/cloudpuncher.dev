<footer class="footer bg-light">
    <div class="container">
        <div class="row justify-content-center text-center">
            <div class="col-md-12">
                <div class="text-center text-white footer-alt">
                    <ul class="list-unstyled list-inline mb-0">
                        <li class="list-inline-item"><a href="#!"><i class="mdi mdi-facebook"></i></a></li>
                        <li class="list-inline-item"><a href="#!"><i class="mdi mdi-linkedin"></i></a></li>
                        <li class="list-inline-item"><a href="#!"><i class="mdi mdi-pinterest"></i></a></li>
                        <li class="list-inline-item"><a href="#!"><i class="mdi mdi-twitter"></i></a></li>
                    </ul>
                    <p class="copyright_content mb-0 mt-3">
                        <script>document.write(new Date().getFullYear())</script>
                        &copy; Kerri. Design by
                        <a class="copyright_content" target="_blank" href="https://themeforest.net/user/srbthemes">SRBThemes.</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</footer>