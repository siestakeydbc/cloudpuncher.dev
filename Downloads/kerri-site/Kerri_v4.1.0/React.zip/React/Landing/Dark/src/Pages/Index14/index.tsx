import React from 'react';
import Section from './Section';

const Index14 = () => {
    return (
        <>
            <Section />
        </>
    );
};

export default Index14;
