import React from 'react';
import Section from './Section';

const Index5 = () => {
    return (
        <>
            <Section />
        </>
    );
};

export default Index5;
