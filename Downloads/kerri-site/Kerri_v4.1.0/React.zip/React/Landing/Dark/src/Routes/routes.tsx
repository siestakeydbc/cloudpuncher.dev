import React from "react";

import Index1 from "../Pages/Index1";
import Index2 from "../Pages/Index2";
import Index3 from "../Pages/Index3";
import Index4 from "../Pages/Index4";
import Index5 from "../Pages/Index5";
import Index6 from "../Pages/Index6";
import Index7 from "../Pages/Index7";
import Index8 from "../Pages/Index8";
import Index9 from "../Pages/Index9";
import Index10 from "../Pages/Index10";
import Index11 from "../Pages/Index11";
import Index12 from "../Pages/Index12";
import Index13 from "../Pages/Index13";
import Index14 from "../Pages/Index14";
import Index15 from "../Pages/Index15";
import Index16 from "../Pages/Index16";
import Index17 from "../Pages/Index17";
import Index18 from "../Pages/Index18";

const routes = [
    { path: "/", component: <Index1 /> },
    { path: "/index-1", component: <Index1 /> },
    { path: "/index-2", component: <Index2 /> },
    { path: "/index-3", component: <Index3 /> },
    { path: "/index-4", component: <Index4 /> },
    { path: "/index-5", component: <Index5 /> },
    { path: "/index-6", component: <Index6 /> },
    { path: "/index-7", component: <Index7 /> },
    { path: "/index-8", component: <Index8 /> },
    { path: "/index-9", component: <Index9 /> },
    { path: "/index-10", component: <Index10 /> },
    { path: "/index-11", component: <Index11 /> },
    { path: "/index-12", component: <Index12 /> },
    { path: "/index-13", component: <Index13 /> },
    { path: "/index-14", component: <Index14 /> },
    { path: "/index-15", component: <Index15 /> },
    { path: "/index-16", component: <Index16 /> },
    { path: "/index-17", component: <Index17 /> },
    { path: "/index-18", component: <Index18 /> },
];

export { routes };