import React from 'react';
import Section from './Section';

const Index16 = () => {
    return (
        <>
            <Section />
        </>
    );
};

export default Index16;
