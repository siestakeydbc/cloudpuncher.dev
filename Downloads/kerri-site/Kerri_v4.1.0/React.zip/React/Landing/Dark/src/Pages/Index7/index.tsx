import React from 'react';
import Section from './Section';

const Index7 = () => {
    return (
        <>
            <Section />
        </>
    );
};

export default Index7;
