import React from 'react';
import Section from './Section';

const Index13 = () => {
    return (
        <>
            <Section />
        </>
    );
};

export default Index13;
