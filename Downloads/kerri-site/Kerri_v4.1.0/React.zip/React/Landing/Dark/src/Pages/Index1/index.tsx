import React from 'react';
import Section from './Section';

const Index1 = () => {
    return (
        <>
            <Section />
        </>
    );
};

export default Index1;
