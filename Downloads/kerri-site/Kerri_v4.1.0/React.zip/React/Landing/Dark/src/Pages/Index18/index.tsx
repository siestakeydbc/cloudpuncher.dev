import React from 'react';
import Section from './Section';

const Index18 = () => {
    return (
        <>
            <Section />
        </>
    );
};

export default Index18;
