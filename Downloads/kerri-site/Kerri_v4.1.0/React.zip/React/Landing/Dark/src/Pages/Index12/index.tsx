import React from 'react';
import Section from './Section';

const Index12 = () => {
    return (
        <>
            <Section />
        </>
    );
};

export default Index12;
