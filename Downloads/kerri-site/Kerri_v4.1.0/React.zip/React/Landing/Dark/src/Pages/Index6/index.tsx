import React from 'react';
import Section from './Section';

const Index6 = () => {
    return (
        <>
            <Section />
        </>
    );
};

export default Index6;
