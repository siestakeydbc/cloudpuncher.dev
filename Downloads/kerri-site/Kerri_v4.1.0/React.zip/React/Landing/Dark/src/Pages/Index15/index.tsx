import React from 'react';
import Section from './Section';

const Index15 = () => {
    return (
        <>
            <Section />
        </>
    );
};

export default Index15;
