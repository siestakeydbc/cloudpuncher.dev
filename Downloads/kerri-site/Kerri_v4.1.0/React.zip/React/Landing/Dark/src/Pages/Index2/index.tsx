import React from 'react';
import Section from './Section';

const Index3 = () => {
    return (
        <>
            <Section />
        </>
    );
};

export default Index3;
