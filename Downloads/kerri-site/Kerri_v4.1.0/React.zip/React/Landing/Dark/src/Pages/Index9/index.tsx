import React from 'react';
import Section from './Section';

const Index9 = () => {
    return (
        <>
            <Section />
        </>
    );
};

export default Index9;
