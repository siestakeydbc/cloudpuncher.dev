import React from 'react';
import Section from './Section';

const Index8 = () => {
    return (
        <>
            <Section />
        </>
    );
};

export default Index8;
