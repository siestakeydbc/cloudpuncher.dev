declare module "react-text-rotator";
declare module "react-particles";